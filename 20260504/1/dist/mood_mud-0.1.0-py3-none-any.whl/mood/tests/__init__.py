"""Tests for MOOD MUD."""
